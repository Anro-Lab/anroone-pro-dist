MSI AI Jinni release artifact
