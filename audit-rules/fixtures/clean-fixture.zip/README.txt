﻿clean fixture
